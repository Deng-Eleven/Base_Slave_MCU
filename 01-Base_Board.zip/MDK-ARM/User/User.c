#include "User.h"
#include "led_font.h"
#include "led_matrix.h"
#include "Touch_Key.h"
#include "Buzzer.h"

#include "stdio.h"

// 外部变量声明
extern TIM_HandleTypeDef TimHandle;
extern uint8_t Key_value;        // 触摸按键键值
UART_HandleTypeDef UartHandle;   // UART 句柄

LED_Matrix_Type Matrix = {0};    // LED 点阵结构体
uint8_t UART_RX_Buff[10];        // UART 接收缓冲区
uint8_t UART_TX_Buff[10];        // UART 发送缓冲区

/*----- 函数声明 -----*/
static void Usart_Communication_Init(void);
static void Touch_Key_Handle(void);
static void Matrix_Dot_Handle(void);
static void Buzzer_Handle(void);
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim);

/**
 * @brief 定时器中断回调函数
 * @param htim: TIM_HandleTypeDef 结构体指针，包含 TIM 模块的配置信息
 * @retval None
 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    if(htim == &TimHandle)
    {
        LEDMatrix_Update(&Matrix);  // 更新 LED 点阵显示
        //LEDMatrix_Text_Draw(&Matrix); // （已注释）在 LED 点阵上绘制文本
    }
}

/**
 * @brief 用户初始化函数
 * @retval None
 */
void User_Init(void)
{   
    /* LED 点阵初始化 */
    LEDMatrix_Init(&Matrix, Grayscale_Off);    // 初始化 LED 点阵，所有 LED 关闭状态
    Loading_Animation(&Matrix, &full, 1);      // 将动画数据加载到 LED 点阵内存中

    /* 触摸按键初始化 */
    Touch_Key_Init();

    /* USART 通讯初始化 */
    Usart_Communication_Init(); // 初始化与主机的 USART 通讯
    HAL_UART_Receive_IT(&UartHandle, UART_RX_Buff, 10); // 开始接收 UART 中断

    /* 蜂鸣器初始化 */
    Buzzer_Init();
}

/**
 * @brief 用户循环函数
 * @retval None
 */
void User_Loop(void)
{
    /* 触摸按键处理 - 10ms 时间片 */
    static uint32_t touch_tick = 0;
    if(touch_tick <= HAL_GetTick())
    {
        touch_tick = HAL_GetTick() + 10;
        Touch_Key_Scanf();  // 扫描触摸按键状态
    }
}

/**
 * @brief USART 接收完成回调函数
 * @param huart: USART 句柄
 * @retval None
 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
    if(UART_RX_Buff[0] == 0x01) // 帧头
    {
        switch(UART_RX_Buff[1]) // 设备码
        {
            case 0x01:  // 触摸按键
            {
                Touch_Key_Handle(); 	// 处理触摸按键数据
            }
            break;
            case 0x02:  // 蜂鸣器
            {
                Buzzer_Handle();    	// 处理蜂鸣器数据
            }
            break;
            case 0x03:  // LED 点阵
            {
                Matrix_Dot_Handle();    // 处理 LED 点阵数据
            }
            break;
            default:
                break;
        }
    }
    HAL_UART_Receive_IT(&UartHandle, UART_RX_Buff, 10); // 重新启动 UART 接收中断
}

/**
 * @brief 处理触摸按键数据
 * @retval None
 */
static void Touch_Key_Handle(void)
{
    if(UART_RX_Buff[2] == 0x00) // 主机查询触摸按键键值
    {
        UART_TX_Buff[0] = 0x02; // 帧头 - 从机发送
        UART_TX_Buff[1] = 0x01; // 设备码 - 触摸按键
        UART_TX_Buff[2] = 0x01; // 功能码 - 返回按键键值
        UART_TX_Buff[3] = 0x02; // 数据长度
        UART_TX_Buff[4] = 0x00; // 数据1 - 无效数据
        UART_TX_Buff[5] = Key_value;    // 按键键值
    }
    HAL_UART_Transmit_IT(&UartHandle, UART_TX_Buff, 6); // 传输 UART 数据
}

/**
 * @brief 处理蜂鸣器数据
 * @retval None
 */
static void Buzzer_Handle(void)
{
    switch(UART_RX_Buff[2])
    {
        case 0x00:  // 关闭蜂鸣器
        case 0x01:  // 开启蜂鸣器
        {
            Buzzer_Set(UART_RX_Buff[2]); // 设置蜂鸣器状态
        }
        break;
        case 0x02:  // 播放歌曲
        {
            // 可以在这里添加播放歌曲的额外功能
        }
        break;
        case 0x03:  // 暂停歌曲
        {
            // 可以在这里添加暂停歌曲的额外功能
        }
        break;
    }
}

/**
 * @brief 处理 LED 点阵数据
 * @retval None
 */
static void Matrix_Dot_Handle(void)
{
    if(UART_RX_Buff[2] == 0x00) // 设置显示动画
    {
        uint16_t num = (UART_TX_Buff[4] << 8) | UART_TX_Buff[5]; // 提取动画编号
        switch(num)
        {
            case 0: Loading_Animation(&Matrix, &full, 1); 		   break; 
            case 1: Loading_Animation(&Matrix, animation_wait, 8); break; 
            default:
                break;  
        }
    }
}

/**
 * @brief USART 通讯初始化函数（当前 MCU 作为从机与主机通讯）
 * @retval None
 */
static void Usart_Communication_Init(void)
{
    /* 初始化 USART */
    UartHandle.Instance = USART2;
    UartHandle.Init.BaudRate = 115200;
    UartHandle.Init.WordLength = UART_WORDLENGTH_8B;
    UartHandle.Init.StopBits = UART_STOPBITS_1;
    UartHandle.Init.Parity = UART_PARITY_NONE;
    UartHandle.Init.HwFlowCtl = UART_HWCONTROL_NONE;
    UartHandle.Init.Mode = UART_MODE_TX_RX;
    UartHandle.Init.OverSampling = UART_OVERSAMPLING_16;
    UartHandle.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
    HAL_UART_Init(&UartHandle); // 初始化 UART 外设
}
