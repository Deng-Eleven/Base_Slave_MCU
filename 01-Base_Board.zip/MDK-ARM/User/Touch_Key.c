#include "Touch_Key.h"

/*
    - [0松开 - 1按下]（00111111） 
    - 最高的两位无效，分别表示KEY-OK、KEY+、KEY-、KEY3、KEY2、KEY1、KEY0的按键状态。
*/

uint8_t Key_value = 0;  // 存储6个触摸按键的按键值

static void set_bit(uint8_t *num, uint8_t bit_position, uint8_t value);

/**
  * @brief  触摸按键初始化函数
  * @param  无
  * @retval 无
  */
void Touch_Key_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    
    // 启用 GPIOA 和 GPIOB 时钟
    __HAL_RCC_GPIOA_CLK_ENABLE();
    __HAL_RCC_GPIOB_CLK_ENABLE();

    // 初始化 KEY_ADD_PIN、KEY_SUB_PIN 和 KEY_OK_PIN 的 GPIO 引脚
    GPIO_InitStruct.Pin = KEY_ADD_PIN | KEY_SUB_PIN | KEY_OK_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;           // 输入模式
    GPIO_InitStruct.Pull = GPIO_PULLUP;               // 上拉
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH; // 高速模式
    HAL_GPIO_Init(KEY_ADD_PORT, &GPIO_InitStruct);

    // 初始化 KEY0_PIN、KEY1_PIN、KEY2_PIN 和 KEY3_PIN 的 GPIO 引脚
    GPIO_InitStruct.Pin = KEY0_PIN | KEY1_PIN | KEY2_PIN | KEY3_PIN;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;           // 输入模式
    GPIO_InitStruct.Pull = GPIO_PULLUP;               // 上拉
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH; // 高速模式
    HAL_GPIO_Init(KEY0_PORT, &GPIO_InitStruct);
}

/**
  * @brief  处理触摸按键状态
  * @param  无
  * @retval 无
  */
void Touch_Key_Scanf(void)
{
    // 检测每个触摸按键的状态并更新 Key_value
    set_bit(&Key_value, 0, (uint8_t)(HAL_GPIO_ReadPin(KEY0_PORT, KEY0_PIN) == TOUCH_PRESS));
    set_bit(&Key_value, 1, (uint8_t)(HAL_GPIO_ReadPin(KEY1_PORT, KEY1_PIN) == TOUCH_PRESS));
    set_bit(&Key_value, 2, (uint8_t)(HAL_GPIO_ReadPin(KEY2_PORT, KEY2_PIN) == TOUCH_PRESS));
    set_bit(&Key_value, 3, (uint8_t)(HAL_GPIO_ReadPin(KEY3_PORT, KEY3_PIN) == TOUCH_PRESS));
    set_bit(&Key_value, 4, (uint8_t)(HAL_GPIO_ReadPin(KEY_ADD_PORT, KEY_ADD_PIN) == TOUCH_PRESS));
    set_bit(&Key_value, 5, (uint8_t)(HAL_GPIO_ReadPin(KEY_SUB_PORT, KEY_SUB_PIN) == TOUCH_PRESS));
    set_bit(&Key_value, 6, (uint8_t)(HAL_GPIO_ReadPin(KEY_OK_PORT, KEY_OK_PIN) == TOUCH_PRESS));
}

/**
  * @brief  设置字节中的特定位
  * @param  num: 操作的字节指针
  * @param  bit_position: 要设置的位位置 (0-7)
  * @param  value: 要设置的值 (0或1)
  * @retval 无
  */
static void set_bit(uint8_t *num, uint8_t bit_position, uint8_t value)
{
    if (value) 
        *num |= (1 << bit_position);   // 将第 bit_position 位设置为1
    else 
        *num &= ~(1 << bit_position);  // 将第 bit_position 位清零
}
