#include "Buzzer.h"

TIM_HandleTypeDef    TimHandle3;
TIM_OC_InitTypeDef sConfig;

void Buzzer_Init(void)
{
    TimHandle3.Instance = TIM3;                                                  /* Select TIM1 */
    TimHandle3.Init.Period            = 1000-1;                                      /* Auto-reload value */
    TimHandle3.Init.Prescaler         = 48-1;                                 /* Prescaler of 800-1 */
    TimHandle3.Init.ClockDivision     = TIM_CLOCKDIVISION_DIV1;                  /* No clock division */
    TimHandle3.Init.CounterMode       = TIM_COUNTERMODE_UP;                      /* Up counting */
    TimHandle3.Init.RepetitionCounter = 1 - 1;                                   /* No repetition counting */
    TimHandle3.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;          /* Auto-reload register not buffered */
    /* Initialize timer base */
    if (HAL_TIM_PWM_Init(&TimHandle3) != HAL_OK)
    {
        APP_ErrorHandler();
    }

    sConfig.OCMode       = TIM_OCMODE_PWM1;                                     /* Configure as PWM1 output */
    sConfig.OCPolarity   = TIM_OCPOLARITY_HIGH;                                 /* OC channel output is active high level */
    sConfig.OCFastMode   = TIM_OCFAST_DISABLE;                                  /* Fast output mode is disabled */
    sConfig.OCNPolarity  = TIM_OCNPOLARITY_HIGH;                                /* OCN channel output is active high level */
    sConfig.OCNIdleState = TIM_OCNIDLESTATE_RESET;                              /* OC1N output is low in idle state */
    sConfig.OCIdleState  = TIM_OCIDLESTATE_RESET;                               /* OC1 output is low in idle state */
    sConfig.Pulse = 0; 

    HAL_TIM_PWM_ConfigChannel(&TimHandle3, &sConfig, TIM_CHANNEL_2);
    HAL_TIM_PWM_Start(&TimHandle3, TIM_CHANNEL_2);
	HAL_TIM_Base_Start(&TimHandle3);
}

void Buzzer_Set(uint8_t state)
{
    if(state)
        __HAL_TIM_SET_COMPARE(&TimHandle3, TIM_CHANNEL_2,(TIM3->ARR + 1) / 2 -1);
    else
        __HAL_TIM_SET_COMPARE(&TimHandle3, TIM_CHANNEL_2,0);
}
 