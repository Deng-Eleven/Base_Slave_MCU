#ifndef __USER_H__
#define __USER_H__

#include "main.h"

void User_Init(void);
void User_Loop(void);

#endif
