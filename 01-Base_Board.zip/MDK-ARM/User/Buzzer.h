#ifndef __BUZZER_H__
#define __BUZZER_H__

#include "main.h"

void Buzzer_Init(void);
void Buzzer_Set(uint8_t state);

#endif
