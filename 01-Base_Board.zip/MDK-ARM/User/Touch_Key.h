#ifndef __TOUCH_KEY_H__
#define __TOUCH_KEY_H__

#include "main.h"

#define TOUCH_PRESS     GPIO_PIN_RESET      //按键按下 - 低电平
#define TOUCH_LOOSEN    GPIO_PIN_SET        //按键松开 - 高电平

/*-----------触摸按键输出接口和MCU硬件接口宏映射-------------*/
/*AI03*/
#define KEY_ADD_PORT    GPIOA
#define KEY_ADD_PIN     GPIO_PIN_4      //KEY+

#define KEY_SUB_PORT    GPIOA
#define KEY_SUB_PIN     GPIO_PIN_6      //KEY-

#define KEY_OK_PORT     GPIOA
#define KEY_OK_PIN      GPIO_PIN_5      //KEY_OK

/*AI04*/
#define KEY0_PORT       GPIOB
#define KEY0_PIN        GPIO_PIN_6

#define KEY1_PORT       GPIOB
#define KEY1_PIN        GPIO_PIN_5

#define KEY2_PORT       GPIOB
#define KEY2_PIN        GPIO_PIN_4

#define KEY3_PORT       GPIOB
#define KEY3_PIN        GPIO_PIN_3

void Touch_Key_Init(void);     
void Touch_Key_Scanf(void);    
#endif
